// #pragma once

// #include "celestia/ast/expressions/AssignmentExpression.hpp"
// #include "celestia/ast/expressions/BinaryExpressionNode.hpp"
// #include "celestia/ast/expressions/CallExpressionNode.hpp"
// #include "celestia/ast/expressions/IndexAcessExpressionNode.hpp"
// #include "celestia/ast/expressions/LiteralExpressionNode.hpp"
// #include "celestia/ast/expressions/MemberAccessExpressionNode.hpp"
// #include "celestia/ast/expressions/UnaryExpressionNode.hpp"
// #include "celestia/ast/statements/BlockStatementNode.hpp"
// #include "celestia/ast/statements/ExpressionStatementNode.hpp"
// #include "celestia/ast/declarations/FunctionDeclaration.hpp"
// #include "celestia/ast/statements/IfStatementNode.hpp"
// #include "celestia/ast/declarations/ImportDeclaration.hpp"
// #include "celestia/ast/statements/ReturnStatementNode.hpp"
// #include "celestia/ast/declarations/VariableDeclaration.hpp"
// #include "celestia/ast/statements/WhileStatementNode.hpp"

// #include <stdexcept>
// #include <string>
// #include <vector>
// #include "celestia/core/operators/BinaryOperation.hpp"
// #include "celestia/core/operators/UnaryOperation.hpp"
// #include "runtime/value/value.hpp"

// enum class OpCode {
//   NOP,
//   PUSH_NUMBER,
//   PUSH_STRING,
//   PUSH_BOOLEAN,
//   PUSH_NULL,
//   PUSH_VOID,
//   PUSH_OBJECT,
//   PUSH_ARRAY,
//   LOAD,
//   STORE,
//   LOAD_FIELD,
//   STORE_FIELD,
//   LOAD_INDEX,
//   STORE_INDEX,
//   ADD,
//   SUB,
//   MUL,
//   DIV,
//   EQ,
//   LT,
//   LTE,
//   GT,
//   GTE,
//   NOT,
//   JUMP,
//   JUMP_IF_FALSE,
//   CALL,
//   RETURN,
//   IMPORT,
//   MODULE,
// };

// struct Instruction {
//   OpCode op;
//   SymbolId var_id = {};
//   Value operand;
//   size_t jump_target = 0;
//   std::string name; // Para campos ou módulos

//   Instruction(OpCode o) : op(o) {}
//   Instruction(OpCode o, SymbolId id) : op(o), var_id(id) {}
//   Instruction(OpCode o, const Value &v) : op(o), operand(v) {}
//   Instruction(OpCode o, size_t target) : op(o), jump_target(target) {}
//   Instruction(OpCode o, const std::string &n) : op(o), name(n) {}
// };

// struct BytecodeGenerator {
//   std::vector<Instruction> code;

//   BytecodeGenerator() = default;

//   void emit(const Instruction &instr) { code.push_back(instr); }
//   const std::vector<Instruction> &get_code() const { return code; }

//   void generate_node(mocelestia::ast::Node *node) {
//     if (!node) return;

//     using NK = celestia::ast::NodeKind;

//     switch (node->kind) {
//     case NK::NumberLiteral: {
//       auto n = static_cast<celestia::ast::NumberLiteralNode *>(node);
//       emit(Instruction(OpCode::PUSH_NUMBER, Value::Number(n->value)));
//       break;
//     }
//     case NK::StringLiteral: {
//       auto s = static_cast<celestia::ast::StringLiteralNode *>(node);
//       emit(Instruction(OpCode::PUSH_STRING, Value::String(s->value)));
//       break;
//     }
//     case NK::BooleanLiteral: {
//       auto b = static_cast<celestia::ast::BoolLiteralNode *>(node);
//       emit(Instruction(OpCode::PUSH_BOOLEAN, Value::Boolean(b->value)));
//       break;
//     }
//     case NK::Name: {
//       auto id = static_cast<celestia::ast::IdentifierExpressionNode *>(node);
//       emit(Instruction(OpCode::LOAD, id->resolved_symbol_id));
//       break;
//     }
//     case NK::BinaryExpression: {
//       auto bin = static_cast<celestia::ast::BinaryExpressionNode *>(node);
//       generate_node(bin->lhs);
//       generate_node(bin->rhs);
     
//       switch (bin->op) {
//       case BinaryOperation::Add: emit(Instruction(OpCode::ADD)); break;
//       case BinaryOperation::Subtract: emit(Instruction(OpCode::SUB)); break;
//       case BinaryOperation::Multiply: emit(Instruction(OpCode::MUL)); break;
//       case BinaryOperation::Divide: emit(Instruction(OpCode::DIV)); break;
//       case BinaryOperation::Equal: emit(Instruction(OpCode::EQ)); break;
//       case BinaryOperation::Less: emit(Instruction(OpCode::LT)); break;
//       case BinaryOperation::LessEqual: emit(Instruction(OpCode::LTE)); break;
//       case BinaryOperation::Greater: emit(Instruction(OpCode::GT)); break;
//       case BinaryOperation::GreaterEqual: emit(Instruction(OpCode::GTE)); break;
//       default: throw std::runtime_error("Operador binário não implementado");
//       }
//       break;
//     }
//     case NK::UnaryExpression: {
//       auto un = static_cast<celestia::ast::UnaryExpressionNode *>(node);
//       generate_node(un->operand);
//       if (un->op == UnaryOperation::Not) emit(Instruction(OpCode::NOT));
//       break;
//     }
//     case NK::VariableDeclaration: {
//       auto var = static_cast<celestia::ast::VariableDeclaration *>(node);
//       if (var->initializer)
//         generate_node(var->initializer);
//       else
//         emit(Instruction(OpCode::PUSH_NULL));
//       auto *id = static_cast<celestia::ast::IdentifierPatternNode *>(var->pattern);
//       emit(Instruction(OpCode::STORE, id->symbol_id));
//       break;
//     }
//     case NK::Assignment: {
//       auto ass = static_cast<celestia::ast::AssignmentExpressionNode *>(node);
//       generate_node(ass->value);
//       switch (ass->target->kind) {
//       case NK::Name: {
//         auto *id = static_cast<celestia::ast::IdentifierExpressionNode *>(ass->target);
//         emit(Instruction(OpCode::STORE, id->resolved_symbol_id));
//         break;
//       }
//       default: throw std::runtime_error("Assignment target não suportado");
//       }
//       break;
//     }
//     case NK::ExpressionStatement: {
//       auto es = static_cast<celestia::ast::ExpressionStatementNode *>(node);
//       generate_node(es->expression);
//       emit(Instruction(OpCode::PUSH_VOID));
//       break;
//     }
//     default: break; // outros nodes podem ser adicionados da mesma forma
//     }
//   }

//   void generate_ast(const std::vector<mocelestia::ast::Node *> &nodes) {
//     for (auto *n : nodes) generate_node(n);
//   }
// };
